import 'package:flutter/material.dart';
import 'Hitung.dart';

void main() {
  runApp(
    MaterialApp(
      home: MenghitungLuasJajarGenjang(),
    )
  );
}

